export const environment = {
  production: true,
  BASEURL:"https://mmdevapi.com/api/v1",
  CLIENT_USERNAME:"USER_CLIENT_APP",
  CLIENT_PASS:"password",
  ENC_SECRET_KEY:"short_code_tech_key",
  VERSION:'1.0.0-SNAPSHOT'
};
