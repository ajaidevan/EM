import { Component, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FrontValidationService } from 'app/services/validation/front-validation.service';
import { PatternValidationService } from 'app/services/validation/pattern-validation.service';



@Component({
  selector: 'ms-login-session',
  templateUrl: './login-component.html',
  styleUrls: ['./login-component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class LoginComponent {

  public loginForm = new FormGroup({
    username: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern)]),
    password: new FormControl('', [Validators.required])
  });

  public resetPasswordForm = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.pattern(this.patternSrv.emailPattern)]),
  });

  public passwordToggleObj = {
    password: true
  };
  
  public showLogin: boolean = true;
  public response:boolean = false;
  public error:boolean = false;
  public loginVal: any;
  public emailForgot: any=this.resetPasswordForm.get('email').value;
  
  constructor(private router:Router,private patternSrv:PatternValidationService, private spinnerService: Ng4LoadingSpinnerService,
    private FrontValSrv: FrontValidationService) { }

 


  ngOnInit() {
     /** Validation Message **/
     this.loginVal = this.FrontValSrv.validationMsg;
  }

  registration(){
    this.router.navigate(['/authentication/register']);
  }

  login(){
    this.router.navigate(['/home']);
  }
  toggleForgotPassword() {
    setTimeout(() => {
      this.showLogin = !this.showLogin;
    }, 2000);
  }
}
