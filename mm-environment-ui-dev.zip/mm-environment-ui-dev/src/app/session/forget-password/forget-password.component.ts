import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FrontValidationService } from 'app/services/validation/front-validation.service';
import { PatternValidationService } from 'app/services/validation/pattern-validation.service';


@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {

  public hide: boolean[] = [true, true, true];
  public forgetPasswordForm: any;
  public forgotPwdVal: any;

  constructor(private patternSrv:PatternValidationService,
    private fb: FormBuilder,  private spinnerService: Ng4LoadingSpinnerService,
    private frontValSrv: FrontValidationService

) {
  // forgot password form validators
  this.forgetPasswordForm = this.fb.group({
    newPassword: ['', [Validators.required, Validators.minLength(8), Validators.pattern(this.patternSrv.pwdPattern)]],
    reTypeNewPassword: ['', [Validators.required, Validators.minLength(8)]]
  });
}

  ngOnInit() {
  }

}
