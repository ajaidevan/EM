import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LimitService {
  limitUrl = "../assets/json-files/limits.json"

  constructor(private http:HttpClient) { }
  getLimit(){
    return this.http.get<any>(this.limitUrl);
  }
}
