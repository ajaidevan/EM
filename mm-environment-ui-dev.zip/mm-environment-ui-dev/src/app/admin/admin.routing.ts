import { Routes } from '@angular/router';
import { LimitManagementComponent } from './limit-management/limit-management.component';


export const AdminsRoutes: Routes = [
  {
    path: '',
    redirectTo: 'admin',
    pathMatch: 'full',
  },{
      path: '',
      children : [
        {
          path:'limit-management',
          component: LimitManagementComponent
        },
      ]
    }
];
