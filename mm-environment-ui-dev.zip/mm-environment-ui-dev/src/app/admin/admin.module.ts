import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatIconModule, MatCardModule, MatButtonModule, MatListModule, MatProgressBarModule, MatMenuModule, MatStepperModule, MatSelectModule, MatRadioModule, MatFormFieldModule, MatInputModule, MatDatepickerModule, MatTableModule, MatPaginatorModule, MatSortModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { AdminsRoutes } from './admin.routing';
import { LimitManagementComponent } from './limit-management/limit-management.component';


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminsRoutes),
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
    MatMenuModule,
    ChartsModule,
    NgxDatatableModule,
    FlexLayoutModule,
    MatStepperModule,
    MatSelectModule,
    MatRadioModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatTableModule,
    MatPaginatorModule,
    MatPaginatorModule,
    MatSortModule
  ],
  declarations: [LimitManagementComponent],
  providers:[]
})

export class AdminModule { }
