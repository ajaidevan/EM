import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { LimitService } from '../services/limit.service';

@Component({
  selector: 'app-limit-management',
  templateUrl: './limit-management.component.html',
  styleUrls: ['./limit-management.component.scss']
})
export class LimitManagementComponent implements OnInit {
  foods: any[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
  public displayedColumns: string[] = ['id', 'customer', 'criteria', 'class', 'actionLimit', 'alertLimit', 'action'];
  public dataSource = new MatTableDataSource();
  constructor(private limitSrv:LimitService) { }

  ngOnInit() {
    this.getAllLimits();
  }

  getAllLimits(){
    this.limitSrv.getLimit().subscribe(data =>{
      this.dataSource = new MatTableDataSource(data);
    });
  }
}
