import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, Validators, FormControl, FormGroupDirective, NgForm } from '@angular/forms';
import { MatSnackBar, ErrorStateMatcher } from '@angular/material';
import { FrontValidationService } from 'app/services/validation/front-validation.service';
import { PatternValidationService } from 'app/services/validation/pattern-validation.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

/** Error when the parent is invalid */
class CrossFieldErrorMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    return (control.dirty || control.touched) && form.invalid;
  }
}


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
})
export class ChangePasswordComponent implements OnInit {

  public hide: boolean[] = [true, true, true];
  public response: string;
  public error: string;
  public resetResponse: string;
  public changedPasswordForm: any;
  public durationInSeconds: number = 5;
  public changePwdVal: any;
  public errorMatcher = new CrossFieldErrorMatcher();

  
  constructor(private router :Router,private patternSrv:PatternValidationService,
    private fb: FormBuilder, private snackBar: MatSnackBar,private spinnerService: Ng4LoadingSpinnerService,
    private frontValSrv: FrontValidationService) { 
      this.changedPasswordForm = this.fb.group({
        currentPassword: ['', [Validators.required, Validators.minLength(8)]],
        newPassword: ['', [Validators.required, Validators.minLength(8), Validators.pattern(this.patternSrv.pwdPattern)]],
        reTypeNewPassword: ['', [Validators.required, Validators.minLength(8)]]
      });
    }

    

  ngOnInit() {
     /** Validation Message **/
     this.changePwdVal = this.frontValSrv.validationMsg;

  }
/** navigate to HOME **/
navigate() {
  this.router.navigate(['/home']);
}
}
