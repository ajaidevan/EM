import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FrontValidationService } from 'app/services/validation/front-validation.service';
import { PatternValidationService } from 'app/services/validation/pattern-validation.service';


@Component({
  selector: 'app-forget-password',
  templateUrl: './activate.component.html',
  styleUrls: ['./activate.component.scss']
})
export class ActivateComponent implements OnInit {

  public hide: boolean[] = [true];
  public activateUserForm: any;
  public activateUserMsg: any;

  constructor(private patternSrv:PatternValidationService,
    private fb: FormBuilder,  private spinnerService: Ng4LoadingSpinnerService,
    private frontValSrv: FrontValidationService){ 
       /** Activate User form **/
       this.activateUserForm = this.fb.group({
        newPassword: ['', [Validators.required, Validators.minLength(8), Validators.pattern(this.patternSrv.pwdPattern)]],
        reTypeNewPassword: ['', [Validators.required, Validators.minLength(8)]]
      });
    }

 ngOnInit() {
        this.activateUserMsg = this.frontValSrv.validationMsg;
     }
// TO DO :: Reset Password
 resetPassword(){}
    
}