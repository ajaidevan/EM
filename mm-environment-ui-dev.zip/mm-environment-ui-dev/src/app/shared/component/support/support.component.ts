import { Component, OnInit} from '@angular/core';
import { MatDialogRef} from '@angular/material';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.scss']
})
export class SupportComponent implements OnInit {

  public version:string ;

  constructor(private dialogRef: MatDialogRef<any>){
    this.version = environment.VERSION;
  }

  ngOnInit() {
    
  }

  /** CLOSE mat dialog **/
  close() {
    this.dialogRef.close(null);
  }
 
}
