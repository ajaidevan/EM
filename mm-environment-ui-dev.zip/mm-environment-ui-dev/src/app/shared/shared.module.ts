import { NgModule } from '@angular/core';

import { MenuItems } from './menu-items/menu-items';
import { HorizontalMenuItems } from './menu-items/horizontal-menu-items';
import { AccordionAnchorDirective, AccordionLinkDirective, AccordionDirective } from './accordion';
import { ToggleFullscreenDirective } from './fullscreen/toggle-fullscreen.directive';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CommonMaterialModule } from './common.module';
import { EllipsisPipe } from './pipes/ellipsis.pipe';
import { IdListPipe } from './pipes/id-list.pipe';
import { ArrayChangePipe } from './pipes/array-change.pipe';
import { MatTableModule } from '@angular/material';
import { SupportComponent } from './component/support/support.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ViewInfoComponent } from './view-info/view-info.component';

@NgModule({
  declarations: [
    EllipsisPipe,
    IdListPipe,
    ArrayChangePipe,
    AccordionAnchorDirective,
    AccordionLinkDirective,
    AccordionDirective,
    ToggleFullscreenDirective,
    SupportComponent,
    ChangePasswordComponent,
    ViewInfoComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    CommonMaterialModule,
    MatTableModule
  ],
  exports: [
    EllipsisPipe,
    IdListPipe,
    ArrayChangePipe,
    AccordionAnchorDirective,
    AccordionLinkDirective,
    AccordionDirective,
    ToggleFullscreenDirective,
  ],
  entryComponents: [SupportComponent,ViewInfoComponent],
  providers: [MenuItems, HorizontalMenuItems]
})
export class SharedModule { }
