import { Injectable } from '@angular/core';

export interface BadgeItem {
  type: string;
  value: string;
}

export interface ChildrenItems {
  state: string;
  name: string;
  type?: string;
  icon?:string;
  subchildren?: SuperChildrenItems[];
}
export interface SuperChildrenItems {
  state: string;
  name: string;
  type?: string;
  supersubchildren?: SuperSubChildrenItems[];
}
export interface SuperSubChildrenItems {
  state: string;
  name: string;
  type?: string;
}
export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
  badge?: BadgeItem[];
  children?: ChildrenItems[];
  accessLevel?: string[];
  subLink?:string;
}

const MENUITEMS: Menu[] = [
  {
    state: 'home',
    name: 'Dashboard',
    type: 'link',
    icon: 'explore',
  },
  {
    state: 'projects',
    name: 'Projects',
    type: 'link',
    icon: 'work',
  },
   {
    state: 'admin',
    name: 'Admin',
    type: 'sub',
    icon: 'face',
    children: [
      { state: 'limit-management', name: 'Limit Management' },
    ]
  }, {
    state: 'projects',
    name: 'QA Approval',
    type: 'subLink',
    subLink:'qa-approval',
    icon: 'graphic_eq',
  },{
    state:'projects',
    name:'Samples Non-Viable',
    icon:'receipt',
    type: 'subLink',
    subLink:'samples-nonviable',
   
 },{
    state: 'projects',
    name: 'Signed-Off Project',
    type: 'subLink',
    subLink:'signed-off',
    icon: 'visibility',
  }, 
];

@Injectable()
export class MenuItems {
  getAll(): Menu[] {
    return MENUITEMS;
  }

  add(menu: Menu) {
    MENUITEMS.push(menu);
  }
}
