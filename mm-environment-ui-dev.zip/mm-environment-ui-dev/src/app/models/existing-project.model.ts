export interface ExistingProject {
    sNo:string;
    customerName: string;
    projectName: string;
    projectType: string;
    createdBy:string;
    createdOn:string;
    Status:string;
  }