export interface NonViableSampleModel {
    sampleId:string,
    roomNo:string,
    location:string,
    0.05:string,
    actionLimit:string,
    alertLimit:string,
    uploadFile:string,
    date:string,
    sampleBy:string
  }
