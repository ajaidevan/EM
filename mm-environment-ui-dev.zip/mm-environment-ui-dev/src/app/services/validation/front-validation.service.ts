import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FrontValidationService {

  constructor() { }

  /** VALIDATION MESSAGE **/

  public validationMsg: any = {
  'email': [
    { type: 'required', message: 'Email is required.' },
    { type: 'pattern', message: 'Email is not valid.' },
    { type: 'maxlength', message: 'Email must be at max 250 characters long.' },
    { type: 'email', message: 'Email is not valid.' },
  ],
  'password': [
    { type: 'required', message: 'Password is required.' },
    { type: 'minlength', message: 'Minmum 8 characters are required.' },
    { type: 'pattern', message: 'Password should contains atleast "1 number, 1 lowercase & 1 uppercase".' }
  ],
  'currentPassword': [
    { type: 'required', message: 'Password is required' },
    { type: 'pattern', message: 'Your password must contain at least one uppercase, one lowercase, one number and be 8 characters long.' }
  ],
  'newPassword': [
    { type: 'required', message: 'Password is required.' },
    { type: 'pattern', message: 'Password must contain at least one uppercase, one lowercase, one number and be 8 characters long.' }
  ],
  'retypePassword': [
    { type: 'required', message: 'Password is required.' },
    { type: 'pattern', message: 'Your password must contain at least one uppercase, one lowercase, one number and be 8 characters long.' },      
  ]
}
}