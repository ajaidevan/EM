import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AirSamplerNonViableComponent } from './air-sampler-non-viable.component';

describe('AirSamplerNonViableComponent', () => {
  let component: AirSamplerNonViableComponent;
  let fixture: ComponentFixture<AirSamplerNonViableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AirSamplerNonViableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AirSamplerNonViableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
