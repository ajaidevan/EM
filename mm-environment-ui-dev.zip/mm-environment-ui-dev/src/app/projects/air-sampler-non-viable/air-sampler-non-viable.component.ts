import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { Router } from '@angular/router';
import { ExistingProject } from 'app/models/existing-project.model';
import { NonViableSampleModel } from 'app/models/air-sampler-non-viable.model';
import { ProjectService } from '../projects.service';


@Component({
  selector: 'app-air-sampler-non-viable',
  templateUrl: './air-sampler-non-viable.component.html',
  styleUrls: ['./air-sampler-non-viable.component.scss']
})
export class AirSamplerNonViableComponent implements OnInit {

  public displayedColumns: string[] = ['sampleId', 'roomNo', 'location', '0.05um', 'actionLimit','alertLimit','0.5um','0.5actionLimit','0.5alertLimit','uploadFile','date','sampleBy','action'];
  public dataSource: MatTableDataSource<NonViableSampleModel>;
  public pageEvent: PageEvent;
  public totalSamples: number;
  public paginate: any = {};

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;



  constructor(private router: Router, private projectService: ProjectService) { this.dataSource = new MatTableDataSource; }

  ngOnInit() {
    this.getNonViableSamples();
  }

  getNonViableSamples() {
    this.projectService.getNonViableSamples().subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
      this.totalSamples = data.length;
    }
    );
  }
  /**Paginate Samples */
  paginateNonViableSamples(setPage = true) {
    if (setPage) this.paginate.page = 0;
  }

  /** On change Page */
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateNonViableSamples(false);
    return event;
  }

  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateNonViableSamples(false);
  }

  // TO DO::ADD go back Functionality
  goBack(){}

  // TO DO::ADD Search functionality
  applyFilter(event){}
}
