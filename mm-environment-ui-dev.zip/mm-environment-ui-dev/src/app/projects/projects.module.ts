import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatIconModule, MatCardModule, MatButtonModule, MatListModule, MatProgressBarModule, MatMenuModule, MatStepperModule, MatSelectModule, MatRadioModule, MatFormFieldModule, MatInputModule, MatDatepickerModule, MatTableModule, MatPaginatorModule, MatSortModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ProjectsComponent } from './projects.component';
import { ProjectsRoutes } from './projects.routing';
import { ProjectInfoComponent } from './project-info/project-info.component';
import { SampleInfoComponent } from './sample-info/sample-info.component';
import { ReviewComponent } from './review/review.component';
import { NewProjectComponent } from './new-project/new-project.component';
import { ProjectService } from './projects.service';
import { ReceivableInfoComponent } from './receivable-info/receivable-info.component';
import { QaApprovalComponent } from './qa-approval/qa-approval.component';
import { ProjectsDraftComponent } from './projects-draft/projects-draft.component';
import { AirSamplerNonViableComponent } from './air-sampler-non-viable/air-sampler-non-viable.component';
import { SignedOffProjectComponent } from './signed-off-project/signed-off-project.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(ProjectsRoutes),
    MatIconModule,
    MatCardModule,
    MatButtonModule,
    MatListModule,
    MatProgressBarModule,
    MatMenuModule,
    ChartsModule,
    NgxDatatableModule,
    FlexLayoutModule,
    MatStepperModule,
    MatSelectModule,
    MatRadioModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatTableModule,
    MatPaginatorModule,
    MatPaginatorModule,
    MatSortModule
  ],
  declarations: [ProjectsComponent, ProjectInfoComponent, SampleInfoComponent, ReviewComponent, NewProjectComponent, ReceivableInfoComponent, QaApprovalComponent,ProjectsDraftComponent, SignedOffProjectComponent,AirSamplerNonViableComponent],
  providers:[ProjectService]
})

export class ProjectsModule { }
