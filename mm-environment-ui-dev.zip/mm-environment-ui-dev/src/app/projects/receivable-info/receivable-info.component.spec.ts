import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReceivableInfoComponent } from './receivable-info.component';

describe('ReceivableInfoComponent', () => {
  let component: ReceivableInfoComponent;
  let fixture: ComponentFixture<ReceivableInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReceivableInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReceivableInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
