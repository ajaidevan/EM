import { Component, OnInit, Output } from '@angular/core';
import { EventEmitter } from 'events';

@Component({
  selector: 'app-receivable-info',
  templateUrl: './receivable-info.component.html',
  styleUrls: ['./receivable-info.component.scss']
})
export class ReceivableInfoComponent implements OnInit {

  constructor() { }
  @Output() receivableInfoData = new EventEmitter();
  ngOnInit() {
  }
  // next(){
  //   this.receivableInfoData.emit('');
  // }
}
