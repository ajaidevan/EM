import { Routes } from '@angular/router';
import { AirSamplerNonViableComponent } from './air-sampler-non-viable/air-sampler-non-viable.component';
import { NewProjectComponent } from './new-project/new-project.component';
import { ProjectsComponent } from './projects.component';
import { QaApprovalComponent } from './qa-approval/qa-approval.component';
import { SignedOffProjectComponent } from './signed-off-project/signed-off-project.component';

export const ProjectsRoutes: Routes = [
  {
    path: '',
    redirectTo: 'projects',
    pathMatch: 'full',
  },{
      path: '',
      children : [
        {
          path:'projects',
          component: ProjectsComponent
        },
        {
          path:'new-project',
          component: NewProjectComponent
        },
        {
          path:'qa-approval',
          component:QaApprovalComponent
        },
        {
          path:'samples-nonviable',
          component:AirSamplerNonViableComponent
        },{
          path:'signed-off',
          component:SignedOffProjectComponent
        }

      ]
    }
];
