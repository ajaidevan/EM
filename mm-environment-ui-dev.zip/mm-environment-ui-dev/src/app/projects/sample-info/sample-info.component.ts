import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { ProjectService } from '../projects.service';

@Component({
  selector: 'app-sample-info',
  templateUrl: './sample-info.component.html',
  styleUrls: ['./sample-info.component.scss']
})
export class SampleInfoComponent implements OnInit,AfterViewInit  {
  foods: any[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
  displayedColumns: string[] = ['position', 'name', 'mfr', 'mfrLotNo','expiration','room','location','action'];
  dataSource = new MatTableDataSource<any>();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private projectSrv:ProjectService) { }

  ngOnInit() {
    this.getSample();
  }

  getSample(){
    this.projectSrv.getSamples().subscribe(data=>{
      this.dataSource = new MatTableDataSource(data);
    });
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
}
