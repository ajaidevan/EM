import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, PageEvent, Sort } from '@angular/material';
import { Router } from '@angular/router';
import { ExistingProject } from 'app/models/existing-project.model';
import { ProjectService } from './projects.service';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.scss']
})
export class ProjectsComponent implements OnInit {

  public displayedColumns: string[] = ['sNo', 'customerName', 'projectName', 'projectType', 'createdBy', 'createdOn', 'status', 'action'];
  public dataSource: MatTableDataSource<ExistingProject>;
  public pageEvent: PageEvent;
  public totalProjects: number;
  public paginate: any = {};
  public loading :boolean=true;


  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private router: Router, private projectService: ProjectService) { this.dataSource = new MatTableDataSource; }

  ngOnInit() {
    this.getProjects();
  }

  openCreateProjects() {
    this.router.navigate(['/projects/new-project']);
  }
  getProjects() {
    this.projectService.getExistingProj().subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
      this.totalProjects = data.length;
    }
    );
  }
  /**Paginate Project */
  paginateProject(setPage = true) {
    if (setPage) this.paginate.page = 0;
  }

  /** On change Page */
  onChangePage(event?: PageEvent) {
    this.paginate.size = event.pageSize;
    this.paginate.page = event.pageIndex;
    this.paginateProject(false);
    return event;
  }

  /*Sorting*/
  sortData(event: Sort) {
    this.paginate.sort = event.active + ',' + event.direction;
    this.paginateProject(false);
  }

  /** SEARCH Projects */
  search(filter) {
  }

   /** Apply Filter */
   applyFilter(filter: any) {
    if (filter.length > 2) {
      this.search(filter);
    }
  
    if (filter.length == 0) {
      this.paginateProject(false);
    }
    
  }
}
