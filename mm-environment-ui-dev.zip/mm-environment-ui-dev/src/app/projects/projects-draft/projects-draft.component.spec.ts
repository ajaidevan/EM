import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectsDraftComponent } from './projects-draft.component';

describe('ProjectsDraftComponent', () => {
  let component: ProjectsDraftComponent;
  let fixture: ComponentFixture<ProjectsDraftComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectsDraftComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectsDraftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
