import { Component, OnInit } from '@angular/core';
import { MatStepper } from '@angular/material';

@Component({
  selector: 'app-new-project',
  templateUrl: './new-project.component.html',
  styleUrls: ['./new-project.component.scss']
})
export class NewProjectComponent implements OnInit {
  public editMode:boolean = false;
  constructor() { }

  ngOnInit() {
  }

  gotoSampleInfo(event,stepper?:MatStepper){
    stepper.next();
  }
}
