import { Component, OnInit ,ViewChild} from '@angular/core';
import { MatPaginator, MatSort, MatTableDataSource, PageEvent, Sort,MatDialog, MatDialogConfig, } from '@angular/material';
import { Router } from '@angular/router';
import { ExistingProject } from 'app/models/existing-project.model';
import { ProjectService } from '../projects.service';
import { ViewInfoComponent } from 'app/shared/view-info/view-info.component';

@Component({
  selector: 'app-qa-approval',
  templateUrl: './qa-approval.component.html',
  styleUrls: ['./qa-approval.component.scss']
})
export class QaApprovalComponent implements OnInit {

  public displayedColumns: string[] = ['sNo', 'customerName', 'projectName', 'projectType', 'createdBy', 'createdOn', 'status', 'action'];
  public awaitingDataSource = new MatTableDataSource();
  public approvedDataSource = new MatTableDataSource();
  public paginateApproved: any = {};
  public paginateApproval: any = {};
  public totalProjectsAwaiting;
  public totalApproved;
  public pageEvent: PageEvent;
  public pageSizeOptions: number[] = [5, 10, 15];
  public selectedRow:any;


  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private router: Router, private projectService: ProjectService,private dialog: MatDialog) {}

  ngOnInit() {
      this.getProjects();
  }
    /** open VIEW INFO **/
    openViewMode(selectedRow) {
      this.selectedRow = selectedRow;
      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;
      dialogConfig.autoFocus = true;
      dialogConfig.data = {
        'selectedValue': this.selectedRow,
        'tableColumns': this.displayedColumns,
        'columnName': ['sNo', 'customerName', 'projectName', 'projectType', 'createdBy', 'createdOn', 'status'],
        "component": "Qa Approval",
        "mode": true
      };
      let dialogRef = this.dialog.open(ViewInfoComponent, dialogConfig);
    }
  
  
  getProjects() {
    this.paginateProject(false,"awaiting", this.paginateApproval);
    this.paginateProject(false, "approved", this.paginateApproved);

  }
   /** Edit receipt by QA */
   onEditProjects(newData?: any): void {
      this.router.navigate(['/projects/new-project']);
  }

  /**Paginate Project */
  paginateProject(setPage = true,tableStatus, paginate) {
    if (tableStatus == 'awaiting') {
     if (setPage) paginate.page = 0;
      this.projectService.getExistingProj().subscribe(data => {
       this.awaitingDataSource = new MatTableDataSource(data);
       this.totalProjectsAwaiting = data.length;
      });
    }
    if (tableStatus == 'approved') {
      if (setPage) paginate.page = 0;
       this.projectService.getExistingProj().subscribe(data => {
        this.approvedDataSource = new MatTableDataSource(data);
        this.totalApproved = data.length;
       });
     }
  }

  /** On change Page */
  onChangePage(event?: PageEvent) {
    this.paginateApproval.size = event.pageSize;
    this.paginateApproval.page = event.pageIndex;
    this.paginateProject(false,"awaiting", this.paginateApproval);
    return event;
  }
   /** On change Page for QA_Approved */
   onChangePageQAApproved(event?: PageEvent) {
    this.paginateApproved.size = event.pageSize;
    this.paginateApproved.page = event.pageIndex;
    this.paginateProject(false,"approved", this.paginateApproved);
    return event;
  }

 /*Sorting*/
 sortData(event: Sort, tableStatus) {
  if (tableStatus == 'awaiting') {
    this.paginateApproval.sort = event.active + ',' + event.direction;
    this.paginateProject(false,  "awaiting", this.paginateApproval);
  }
  if (tableStatus == 'approved') {
    this.paginateApproved.sort = event.active + ',' + event.direction;
    this.paginateProject(false,  "approved", this.paginateApproved);
  }
 }
 
}
