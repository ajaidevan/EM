import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SignedOffProjectComponent } from './signed-off-project.component';

describe('SignedOffProjectComponent', () => {
  let component: SignedOffProjectComponent;
  let fixture: ComponentFixture<SignedOffProjectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SignedOffProjectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignedOffProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
