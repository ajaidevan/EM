import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExistingProject } from 'app/models/existing-project.model';
import { NonViableSampleModel } from 'app/models/air-sampler-non-viable.model';


@Injectable({
    providedIn: 'root'
  })
  export class ProjectService {
  
    private httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    constructor(private http: HttpClient) { }
  
    private existingProjUrl = "../assets/json-files/existing-project.json";
    private nonviableSamplesUrl="../assets/json-files/non-viable-sample.json"
    private samleUrl =  "../assets/json-files/sample.json";
    private approvedSampleUrl = "../assets/json-files/approved-samples.json";
     getExistingProj(): Observable<ExistingProject[]> {
       return this.http.get<ExistingProject[]>(this.existingProjUrl,this.httpOptions);
     }
     getNonViableSamples():Observable<NonViableSampleModel[]>{
      return this.http.get<NonViableSampleModel[]>(this.nonviableSamplesUrl,this.httpOptions);
   }

   getSamples(){
    return this.http.get<any>(this.samleUrl);
   }
   getApprovedSamples(){
     return this.http.get<any>(this.approvedSampleUrl);
   }
}