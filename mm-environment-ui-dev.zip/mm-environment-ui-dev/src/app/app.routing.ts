import { Routes } from '@angular/router';
import { AdminLayoutComponent } from './layouts/admin/admin-layout.component';
import { AuthLayoutComponent } from './layouts/auth/auth-layout.component';
import { ChangePasswordComponent } from './shared/change-password/change-password.component';

export const AppRoutes: Routes = [
  {
    path: '',
    redirectTo: '/authentication/login',
    pathMatch: 'full',
  }, {
    path: '',
    component: AdminLayoutComponent,
    children: [{
      path: 'home',
      loadChildren: './dashboard/dashboard.module#DashboardModule',
    },{
      path: 'change-password',
      component: ChangePasswordComponent,    
    },{
      path: 'projects',
      loadChildren: './projects/projects.module#ProjectsModule',
    },{
      path: 'admin',
      loadChildren: './admin/admin.module#AdminModule',
    },
    ]
  }, {
    path: '',
    component: AuthLayoutComponent,
    children: [{
      path: 'authentication',
      loadChildren: './session/session.module#SessionModule',
    }]
  }, {
    path: '**',
    redirectTo: 'error/404'
  }
];







